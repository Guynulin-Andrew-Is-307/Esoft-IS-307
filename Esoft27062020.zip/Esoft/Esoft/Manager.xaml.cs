﻿using System;
using System.Windows;
using MySql.Data.MySqlClient;
using Tutorial.SqlConn;
using System.Data;

namespace Esoft
{
    public partial class Manager : Window
    {
        public User user;
        DataTable datatable; // Таблица являющиеся источником данных для заполнения DataGrid

        public Manager()
        {
            InitializeComponent();
        }

        //Установить начальные значения при запуске
        public void SetValue(User pUser)
        {
     
            FullName.Text = pUser.FullName;
            ReloadTasks(pUser.id.ToString()); // Обновить список задач
            Commons SetV = new Commons(); // Вызов общего класса
            SetV.SetListPerformers(taskexec, pUser.id.ToString()); // Обновить список исполнителей для фильтра

        }

        //Смена пользователя
        private void ButtonExit(object sender, RoutedEventArgs a)
        {
            MessageBoxResult reuslt = MessageBox.Show("Вы уверены, что хотите сменить пользователя?", "Сменить пользователя?"
                 , MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No);
            if (MessageBoxResult.Yes == reuslt)
            {
                Authorization NewSea = new Authorization();
                NewSea.Show();
                this.Close();
            };

        }

        //Открытие формы коэфицентов
        private void ButtonOpenCoefficients(object sender, RoutedEventArgs a)
        {
            Coefficients Coefficientswindow = new Coefficients
            {
                user = user /*Ввод стандартных переменных*/
            };
            Coefficientswindow.SetValue(user.Login, user.FullName, user.id); //Установить начальные значения
            Coefficientswindow.Show();  // Показать
        }



        //Открытие формы коэфицентов
        private void ButtonOpenRoll(object sender, RoutedEventArgs a)
        {
            Payroll payroll = new Payroll
            {
                user = user
            };

            payroll.SetValue(user);
            payroll.Show();  // Показать
        }


        //Кнопка для просмотра всех исполниителей
        private void ButtonAllPerformers(object sender, RoutedEventArgs a)
        {
            AllExecutors AllPerform = new AllExecutors();
            AllPerform.SetValue(user);
            AllPerform.Show(); 
        }

        //Кнопка для просмотра всех задач
        private void ButtonAllTasks(object sender, RoutedEventArgs a)
        {
            AllTasks Alliasks = new AllTasks();
            Alliasks.SetValue(user);
            Alliasks.Show();
        }

        //Отредактировать задачу
        private void ButtonReditTask(object sender, RoutedEventArgs a)
        {
            int idtask = Convert.ToInt32(datatable.Rows[TasksForExecutors.SelectedIndex][0]);

            AddTask AddTaskwindow = new AddTask
            {
                
                user = user,
                id_task = idtask
            };
            AddTaskwindow.SetValue(user.Login, user.FullName, user.id, user.TypeUser, idtask); 
            AddTaskwindow.Owner = this;
            AddTaskwindow.Show(); 
        }


        //Обновить список задач 
        private void ButtonReloadTask(object sender, RoutedEventArgs a)
        {
            ReloadTasks(user.id.ToString());
        }

        //Удалить задачу
        private void ButtonDeletedTask(object sender, RoutedEventArgs a)
        {
            MessageBoxResult reuslt = MessageBox.Show("Вы уверены, что хотите удалить задачу?", "Удалить задачу?"
                , MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No);
            if (MessageBoxResult.Yes == reuslt)
            {

                string idtask = datatable.Rows[TasksForExecutors.SelectedIndex][0].ToString();
                MySqlConnection db = DBUtils.GetDBConnection();
                try
                {
                    db.Open();
                    MySqlCommand cmd = new MySqlCommand("UPDATE `task` SET  deleted = 1 WHERE id = " + idtask)
                    { Connection = db };
                    cmd.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    MessageBox.Show("Не удалось удалить задачу! Информация об ошибке: " + e);
                }
                finally
                {
                    db.Close();
                    db.Dispose();
                    ReloadTasks(user.id.ToString());
                }

            }

        }

        //Кнопка для создания новой задача
        private void ButtonOpenTasks(object sender, RoutedEventArgs a)
        {
            AddTask AddTaskwindow = new AddTask
            {
                /*Ввод стандартных переменных*/
                user = user
            };
            AddTaskwindow.SetValue(user.Login, user.FullName, user.id, user.TypeUser); //Установить начальные значения
            AddTaskwindow.Owner = this; // Установка владельца
            AddTaskwindow.Show();  // Показать
        }

        //Обновить список задач
        public void ReloadTasks(string pid)
        {
            
            TasksForExecutors.ItemsSource = null;
            MySqlConnection db = DBUtils.GetDBConnection();
            try
            {
                db.Open();
                //Обновить таблицу задач
                datatable = new DataTable("task");

                MySqlCommand command = new MySqlCommand("SELECT id, Status AS Статус, Name As Задача, (SELECT FullName FROM `user` WHERE id = `task`.Performer_id) AS Исполнитель, Complexity As Сложность,  DateCreate AS `Задача создана`, LeadTime, PerformanceDate AS Дедлайн,  DateCompletion AS `Дата завершения`, TypeWork AS `Характер работы` FROM `task` WHERE deleted = 0 AND Performer_id IN (SELECT Performer_id FROM subgroups WHERE deleted = 0 AND Manager_id = " + pid.ToString() + ") "
                    + (taskstatus.SelectedIndex > 0 ? " AND Status = '" + taskstatus.Text + "' " : "")
                    + (taskexec.SelectedIndex > 0 ? " AND Performer_id = '" + taskexec.Text.Split(' ')[0] + "' " : "")
                    + " ORDER BY id")
                {
                    Connection = db
                };
                command.ExecuteNonQuery();
                //Поставить типы из результат
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                //Обновить строки по таблице
                adapter.Fill(datatable);

             
                //Форматирование минут в часы и минуты
                datatable.Columns.Add(
                new DataColumn
                {
                    DataType = typeof(string),
                    ColumnName = "Времени на выполнение",
                });

                for (int i = 0; i < datatable.Rows.Count; i++)
                {
                    int minutes = Convert.ToInt32(datatable.Rows[i][6]);
                    int hour = minutes / 60;
                    datatable.Rows[i][10] = hour.ToString() + "ч. " + (minutes - hour * 60).ToString() + " мин.";
                   
                };

                datatable.Columns.RemoveAt(6);
                datatable.Columns[9].SetOrdinal(6);

                //Установить только для чтения
                for (int i = 0; i < datatable.Columns.Count; i++)
                {
                    datatable.Columns[i].ReadOnly = true;
                };

                //Установить таблицу
                TasksForExecutors.ItemsSource = datatable.DefaultView;
            }
            catch (Exception e)
            {
                MessageBox.Show("Не удалось подключиться к базе данных или серверу при получении задач! Информация об ошибке: " + e);
            }
            finally
            {
                // Закрыть соединение.
                db.Close();
                // Уничтожить объект, освободить ресурс.
                db.Dispose();
            }
        }
    }
}
