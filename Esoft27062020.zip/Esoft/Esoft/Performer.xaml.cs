﻿using System;
using System.Windows;
using MySql.Data.MySqlClient;
using Tutorial.SqlConn;
using System.Data;

namespace Esoft
{


    public partial class Executor : Window
    {
        public User user;
        DataTable datatable; // Таблица для динамического заполнения DataGrid из запроса 

        public Executor()
        {
            InitializeComponent();
        }

        //Установить начальные значения 
        public void SetValue(User pUser)
        {
            FullName.Text = pUser.FullName;
            ReloadTasks(pUser.id.ToString());
        }

        //Смена пользователя
        private void ButtonExit(object sender, RoutedEventArgs a)
        {
            MessageBoxResult reuslt = MessageBox.Show("Вы уверены, что хотите сменить пользователя?", "Сменить пользователя?"
                 , MessageBoxButton.YesNo, MessageBoxImage.Question, MessageBoxResult.No);
            if (MessageBoxResult.Yes == reuslt)
            {
                Authorization NewSea = new Authorization();
                NewSea.Show();
                this.Close();
            };

        }

        //Обновить список задач 
        private void ButtonReloadTask(object sender, RoutedEventArgs a)
        {
            ReloadTasks(user.id.ToString());
        }

        //Открытие рассчета зарплаты
        private void ButtonOpenRoll(object sender, RoutedEventArgs a)
        {
            Payroll payroll = new Payroll
            {
                user = user
            };

            payroll.SetValue(user);
            payroll.Show();  // Показать
        }

        //Отредактировать задачу
        private void ButtonReditTask(object sender, RoutedEventArgs a)
        {
            int idtask = Convert.ToInt32(datatable.Rows[TasksForExecutors.SelectedIndex][0]);
            AddTask AddTaskwindow = new AddTask
            {

                user = user,
                id_task = idtask
            };
            AddTaskwindow.SetValue(user.Login, user.FullName, user.id, user.TypeUser, idtask);
            AddTaskwindow.Owner = this;
            AddTaskwindow.Show();
        }


        //Обновить список задач
        public void ReloadTasks(string pid)
        {

            TasksForExecutors.ItemsSource = null;
            MySqlConnection db = DBUtils.GetDBConnection();
            try
            {
                db.Open();
                //Обновить таблицу задач
                datatable = new DataTable("task");

                MySqlCommand command = new MySqlCommand("SELECT id, Status AS Статус, Name As Задача, Complexity As Сложность,  DateCreate AS `Задача создана`, LeadTime, PerformanceDate AS Дедлайн,  DateCompletion AS `Дата завершения`, TypeWork AS `Характер работы` FROM `task` WHERE deleted = 0"
                    + (taskstatus.SelectedIndex > 0 ? " AND Status = '" + taskstatus.Text + "' " : "")
                    + " AND Performer_id = " + pid
                    + " ORDER BY id")
                {
                    Connection = db
                };
                command.ExecuteNonQuery();
                //Поставить типы из результат
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                //Обновить строки по таблице
                adapter.Fill(datatable);


                //Форматирование минут в часы и минуты
                datatable.Columns.Add(
                new DataColumn
                {
                    DataType = typeof(string),
                    ColumnName = "Времени на выполнение",
                });

                for (int i = 0; i < datatable.Rows.Count; i++)
                {
                    int minutes = Convert.ToInt32(datatable.Rows[i][5]);
                    int hour = minutes / 60;
                    datatable.Rows[i][9] = hour.ToString() + "ч. " + (minutes - hour * 60).ToString() + " мин.";

                };

                datatable.Columns.RemoveAt(5);
                datatable.Columns[8].SetOrdinal(5);

                for (int i = 0; i < datatable.Columns.Count; i++)
                {
                    datatable.Columns[i].ReadOnly = true;
                };
                //Установить таблицу
                TasksForExecutors.ItemsSource = datatable.DefaultView;

                //Обновить данные в таблице данных
                //adapter.Update(datatable);
            }
            catch (Exception e)
            {
                MessageBox.Show("Не удалось подключиться к базе данных или серверу при получении задач! Информация об ошибке: " + e);
            }
            finally
            {
                // Закрыть соединение.
                db.Close();
                // Уничтожить объект, освободить ресурс.
                db.Dispose();
            }
        }
    }
}
