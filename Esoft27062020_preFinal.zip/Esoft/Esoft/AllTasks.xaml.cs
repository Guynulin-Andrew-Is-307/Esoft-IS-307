﻿using System;
using System.Windows;
using MySql.Data.MySqlClient;
using Tutorial.SqlConn;
using System.Data;
using System.Data.Common;

namespace Esoft
{


    public partial class AllTasks : Window
    {
        DataTable datatable; // Таблица для динамического заполнения DataGrid из запроса 

        public void SetValue(User pUser)
        {
            FullName.Text = pUser.FullName;

        }

        public AllTasks()
        {
            InitializeComponent();
            ReloadTasks();
            MySqlConnection db = DBUtils.GetDBConnection();
            try
            {
                Manager.Items.Clear();
                Manager.Items.Add("-Фильтр по Менеджеру-");
                db.Open();
                //Получить список менджерова для фильтра
                MySqlCommand cmd = new MySqlCommand("SELECT FullName, id FROM `user` WHERE TypeUser = 'Менеджер' AND deleted = 0 ORDER BY id")
                {
                    Connection = db
                };
                using (DbDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Manager.Items.Add(reader.GetString(1) + " " + reader.GetString(0));
                    };
                    reader.Close();
                };

                taskexec.Items.Clear();
                taskexec.Items.Add("-Фильтр по исполнителю-");
                //Получить список исполнителей для фильтра
                cmd.CommandText = "SELECT FullName, id FROM `user` WHERE TypeUser = 'Исполнитель' AND deleted = 0 ORDER BY id";
                using (DbDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        taskexec.Items.Add(reader.GetString(1) + " " + reader.GetString(0));
                    };
                };
            }
            catch (Exception e)
            {
                MessageBox.Show("Не удалось подключиться к базе данных или серверу при получении менеджеров и исполнителей! Информация об ошибке: " + e);
            }
            finally
            {
                db.Close();
                db.Dispose();
            }

        }

        //Обновить список задач 
        private void ButtonReloadTask(object sender, RoutedEventArgs a)
        {
            ReloadTasks();
        }

        //Обновить список задач
        public void ReloadTasks()
        {

            TasksForExecutors.ItemsSource = null;
            MySqlConnection db = DBUtils.GetDBConnection();
            try
            {
                db.Open();
                //Обновить таблицу задач
                datatable = new DataTable("task");

                MySqlCommand command = new MySqlCommand("SELECT id, (SELECT FullName FROM `user` WHERE id = (SELECT Manager_id FROM `subgroups` WHERE Performer_id = `task`.Performer_id)) AS Менеджер, Status AS Статус, Name As Задача, (SELECT FullName FROM `user` WHERE id = `task`.Performer_id) AS Исполнитель, Complexity As Сложность,  DateCreate AS `Задача создана`, LeadTime, PerformanceDate AS Дедлайн,  DateCompletion AS `Дата завершения`, TypeWork AS `Характер работы` FROM `task` WHERE deleted = 0 "
                    + (taskstatus.SelectedIndex > 0 ? " AND Status = '" + taskstatus.Text + "' " : "")
                    + (taskexec.SelectedIndex > 0 ? " AND Performer_id = '" + taskexec.Text.Split(' ')[0] + "' " : "")
                    + (Manager.SelectedIndex > 0 ? " AND Performer_id IN (SELECT Performer_id FROM `subgroups` WHERE Manager_id = " + Manager.Text.Split(' ')[0] + ") " : "")
                    + " ORDER BY id")
                {
                    Connection = db
                };
                command.ExecuteNonQuery();
                //Поставить типы из результат
                MySqlDataAdapter adapter = new MySqlDataAdapter(command);
                //Обновить строки по таблице
                adapter.Fill(datatable);


                //Форматирование минут в часы и минуты
                datatable.Columns.Add(
                new DataColumn
                {
                    DataType = typeof(string),
                    ColumnName = "Времени на выполнение",
                });

                for (int i = 0; i < datatable.Rows.Count; i++)
                {
                    int minutes = Convert.ToInt32(datatable.Rows[i][7]);
                    int hour = minutes / 60;
                    datatable.Rows[i][11] = hour.ToString() + "ч. " + (minutes - hour * 60).ToString() + " мин.";

                };

                datatable.Columns.RemoveAt(7);
                datatable.Columns[10].SetOrdinal(7);

                //Установить только для чтения
                for (int i = 0; i < datatable.Columns.Count; i++)
                {
                    datatable.Columns[i].ReadOnly = true;
                };
                //Установить таблицу
                TasksForExecutors.ItemsSource = datatable.DefaultView;
            }
            catch (Exception e)
            {
                MessageBox.Show("Не удалось подключиться к базе данных или серверу при получении задач! Информация об ошибке: " + e);
            }
            finally
            {
                // Закрыть соединение.
                db.Close();
                // Уничтожить объект, освободить ресурс.
                db.Dispose();
            }
        }
    }
}
