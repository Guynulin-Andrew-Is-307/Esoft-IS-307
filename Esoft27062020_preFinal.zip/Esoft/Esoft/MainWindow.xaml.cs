﻿using System;
using System.Windows;
using System.Windows.Input;
using MySql.Data.MySqlClient;
using Tutorial.SqlConn;
using System.Data.Common;
using System.Windows.Media;
using System.Threading;

namespace Esoft
{
    public partial class Authorization : Window

    {


        SolidColorBrush ActiveBrush = new SolidColorBrush(Color.FromRgb(4, 160, 255));
        SolidColorBrush PassivBrush = new SolidColorBrush(Color.FromRgb(168, 187, 197));
        int Tript = 3;

        public Authorization()
        {            
            InitializeComponent();
            //Password.Password = "1";
            //Login.Text = "velizhanina";
            //Login.Text = "kremlev";
        }


        //Активациия кнопки входа при вводе в Логине
        private void ButtStyleLogin(object sender, KeyEventArgs e)
        {

            if (e.Key == Key.Back && Login.Text.Length == 1)
            {
                ButtonInput.Background = PassivBrush;
            }
            else if(Password.Password.Length != 0 && Login.Text.Length != 0)
            {
                ButtonInput.Background = ActiveBrush;
            }
            else
            {
                ButtonInput.Background = PassivBrush;
            };
        }

        //Активациия кнопки входа при вводе в Пароле
        private void ButtStylePassword(object sender, KeyEventArgs e)
        {

            if (e.Key == Key.Back && Password.Password.Length == 1)
            {
                ButtonInput.Background = PassivBrush;
            }
            else if (Login.Text.Length != 0)
            {
                ButtonInput.Background = ActiveBrush;
            }
            else
            {
                ButtonInput.Background = PassivBrush;
            };
        }

        public  void Count()
        {
            Tript = 3;
        }


        private void ButtonAuthorization(object sender, RoutedEventArgs a)
        {
            if (Tript == 0) { 
                MessageBox.Show( "Превышено максимальное количество попыток входа. Подождите немного.","Блокировка на время", MessageBoxButton.OK, MessageBoxImage.Stop);

                Password.Password = "";
                Login.Text = "";
                ButtonInput.Background = PassivBrush;

                /*int num = 0;
                TimerCallback tm = new TimerCallback(Count);
                Timer timer = new Timer(tm, num, 15000, 600000);*/
                Count();
            }
            else
            {
                //Подключение к таблице
                MySqlConnection db = DBUtils.GetDBConnection();
                try
                {
                    db.Open();
                    //Проверка совпадение логина и пароля
                    MySqlCommand cmd = new MySqlCommand("SELECT id, Login, FullName, TypeUser FROM `user` WHERE Login = '" + Login.Text.Replace("'", "''") + "' AND Password = '" + Password.Password.Replace("'", "''") + "' AND deleted = 0")
                    {
                        Connection = db
                    };

                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        if (!reader.Read())
                        {

                            MessageBox.Show("Введен не правильный логин или пароль!", "Неудачная попытка авторизации", MessageBoxButton.OK, MessageBoxImage.Stop);

                            Password.Password = "";
                            Login.Text = "";
                            ButtonInput.Background = PassivBrush;

                            Tript -= 1;
                        }
                        else
                        {
                            //Заполнение информации о пользователе
                            User user = new User
                            {
                                id = reader.GetInt32(0),
                                Login = reader.GetString(1),
                                FullName = reader.GetString(2),
                                TypeUser = reader.GetString(3),
                            };

                            //Открытие рабочеего стола по роли пользователя
                            if (user.TypeUser == "Менеджер")
                            {
                                Manager Userwindow = new Manager { user = user };
                                Userwindow.SetValue(user); //Установить начальные значения
                                Userwindow.Show(); // Показать
                            }
                            else
                            {
                                Executor Userwindow = new Executor { user = user };
                                Userwindow.SetValue(user); //Установить начальные значения
                                Userwindow.Show();  // Показать
                            };
                            this.Close(); // Закрыть окно авторизации


                        };
                    };
                }
                catch (Exception e)
                {

                    MessageBox.Show("Не удалось подключиться к базе данных или серверу! Информация об ошибке: " + e, "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                finally
                {
                    // Закрыть соединение.
                    db.Close();
                    // Уничтожить объект, освободить ресурс.
                    db.Dispose();
                }
            }
        }
    }

}
