﻿using System;
using System.Windows;
using MySql.Data.MySqlClient;
using Tutorial.SqlConn;
using System.Data;
using System.Data.Common;
namespace Esoft
{
    /// <summary>
    /// Логика взаимодействия для Payroll.xaml
    /// </summary>
    public partial class Payroll : Window
    {
        public User user;

        string Gr = ""; // grade
        double Gm = 0; // зп  по грейду

        double GmJ = 0; // далее коэфы менджера
        double GmM = 0;
        double GmS = 0;
        double CiA = 0;
        double CiI = 0;
        double CiS = 0;
        double Tc = 0;
        double Dc = 0;
        double Tb = 0;


        public Payroll()
        {
            InitializeComponent();

            Total.Text = "0 руб.";
            TotalTask.Text = "0";
        }

        //Установить начальные значения при запуске
        public void SetValue(User pUser)
        {
            if (pUser.TypeUser == "Менеджер")
            {
                Commons SetV = new Commons();
                MySqlConnection db = DBUtils.GetDBConnection();
                try
                {
                    taskexec.Items.Clear();
                    db.Open();
                    MySqlCommand cmd = new MySqlCommand("SELECT FullName, id FROM `user` WHERE TypeUser = 'Исполнитель' AND deleted = 0 AND id IN (SELECT Performer_id FROM subgroups WHERE deleted = 0 AND Manager_id = " + pUser.id.ToString()
                        + ") ORDER BY id")
                    {
                        Connection = db
                    };
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            taskexec.Items.Add(reader.GetString(1) + " " + reader.GetString(0));
                        };
                        taskexec.SelectedIndex = 0;
                    };
                }
                catch (Exception e)
                {
                    MessageBox.Show("Не удалось подключиться к базе данных или серверу при получении исполнителей! Информация об ошибке: " + e);
                }
                finally
                {
                    db.Close();
                    db.Dispose();
                }
                ReloadCoef(pUser.id);
            }
            else
            {
                
                MySqlConnection db = DBUtils.GetDBConnection();
                try
                {
                    db.Open();
                    MySqlCommand cmd = new MySqlCommand("SELECT Grade FROM `performer` WHERE Performer_id = " + pUser.id.ToString() + " AND deleted = 0"
                       )
                    {
                        Connection = db
                    };
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            Gr = reader.GetString(0);
                        };
                        reader.Close();
                    };
                    
                    cmd.CommandText = "SELECT Manager_id FROM `subgroups` WHERE Performer_id = " + pUser.id.ToString() + " AND deleted = 0";
                    using (DbDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            
                            ReloadCoef(reader.GetInt32(0));
                        };
                    };

                   
                }
                catch (Exception e)
                {
                    MessageBox.Show("Не удалось подключиться к базе данных или серверу при получении исполнителей! Информация об ошибке: " + e);
                }
                finally
                {
                    db.Close();
                    db.Dispose();
                }

                taskexec.Visibility = Visibility.Hidden;
            }
        }

  
        private void ButtonTotal(object sender, RoutedEventArgs a)
        {

            

            MySqlConnection db = DBUtils.GetDBConnection();
            try
            {
                db.Open();
                DataTable datatable = new DataTable("task");
                //Получить кол-во выполненых задач исполнителем                                                                          
                MySqlCommand cmd = new MySqlCommand("SELECT id, Name As Задача, Complexity As Сложность,  DateCreate AS `Задача создана`, LeadTime AS `Время на выполнение`, PerformanceDate AS Дедлайн,  DateCompletion AS `Дата завершения`, TypeWork AS `Характер работы`FROM `task` WHERE deleted = 0 AND Status = 'Завершена'  AND Performer_id = " 
                    + (user.TypeUser == "Менеджер" ? taskexec.Text.Split(' ')[0] : user.id.ToString()) 
                    + " AND date_format(DateCompletion, '%Y%m') = date_format(now(), '%Y%m')" +
                    " ORDER BY id"
                )
                {
                    Connection = db
                };
                cmd.ExecuteNonQuery();
                //Поставить типы из результат
                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                //Обновить строки по таблице
                adapter.Fill(datatable);

                //Установить только для чтения
                for (int i = 0; i < datatable.Columns.Count; i++)
                {
                    datatable.Columns[i].ReadOnly = true;
                };

                //Установить таблицу
                TasksForExecutors.ItemsSource = datatable.DefaultView;

                if (user.TypeUser == "Менеджер") {


                    cmd.CommandText = "SELECT Grade FROM `performer` WHERE Performer_id = " + taskexec.Text.Split(' ')[0] + " AND deleted = 0";
                        using (DbDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                Gr = reader.GetString(0);
                            };
                            reader.Close();
                        };

                }

                if (Gr == "junior")
                {
                    Gm = GmJ;
                }
                else if (Gr == "middle")
                {
                    Gm = GmM;
                }
                else
                {
                    Gm = GmS;
                };


                
                
                TotalTask.Text = datatable.Rows.Count.ToString();

                double TlTask = 0;

                senior.Text = "Гарантированый минимум: " + Gm.ToString();
                analysis.Text = "analysis: " + CiA.ToString();
                installation.Text = "installation: " + CiI.ToString();
                support.Text = "support: " + CiS.ToString();
                TimeRatio.Text = "Коэф. времени: " + Tc.ToString();
                DifficultyRatio.Text = "Коэф. сложности: " + Dc.ToString();
                CashEquivalent.Text = "Доп. коэф: " + Tb.ToString();

                for (int i = 0; i< datatable.Rows.Count; i++) {
                    TlTask += Dc*Convert.ToInt32( datatable.Rows[i][2] ); // Сложность
                    TlTask += Tc*Convert.ToInt32( datatable.Rows[i][4] ); // Время на выполнение
                    string typeT = datatable.Rows[i][7].ToString(); // Характер работы
                    if (typeT == "Анализ и проектирование") {
                        TlTask += CiA * Tb;
                    } else if (typeT == "Установка оборудования") {
                        TlTask += CiI * Tb;
                    } else {
                        TlTask += CiS * Tb;
                    };
                };

                TlTask += Gm; 


                Total.Text = TlTask.ToString() + " руб."; // Итоговая формула

            }
            catch (Exception e)
            {
                MessageBox.Show("Не удалось подключиться к базе данных или серверу при получении задач! Информация об ошибке: " + e);
            }
            finally
            {
                // Закрыть соединение.
                db.Close();
                // Уничтожить объект, освободить ресурс.
                db.Dispose();
            }
        }

        //Установка начальных значений
        public void ReloadCoef(int pid)
        {

            MySqlConnection db = DBUtils.GetDBConnection();
            try
            {
                db.Open();

                MySqlCommand cmd = new MySqlCommand("SELECT junior,middle,senior,analysis,installation,support,time_coef,diff_coef,cash_coef FROM `managers_coef` WHERE Manager_id = '" + pid.ToString() + "' AND deleted = 0");

                cmd.Connection = db;

                using (DbDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read()) {

                        /*junior.Text = reader.GetString(0);
                        middle.Text = reader.GetString(1);
                        senior.Text = reader.GetString(2);*/


                        GmJ = reader.GetDouble(0);
                        GmM = reader.GetDouble(1);
                        GmS = reader.GetDouble(2);
                        CiA = reader.GetDouble(3);
                        CiI = reader.GetDouble(4);
                        CiS = reader.GetDouble(5);
                        Tc = reader.GetDouble(6);
                        Dc = reader.GetDouble(7);
                        Tb = reader.GetDouble(8);
                    };
                };

            }
            catch (Exception e)
            {
                MessageBox.Show("Не удалось подключиться к базе данных или серверу при получении и установке начальных значений! Информация об ошибке: " + e);
            }
            finally
            {
                // Закрыть соединение.
                db.Close();
                // Уничтожить объект, освободить ресурс.
                db.Dispose();
            }
        }
    }
}
