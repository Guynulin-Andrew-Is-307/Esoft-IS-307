﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Esoft
{
    /********/
    public partial class User
    {
        public int id { get; set; }
        public string Login { get; set; }
        public string FullName { get; set; }
        public string TypeUser { get; set; }
    }

}
